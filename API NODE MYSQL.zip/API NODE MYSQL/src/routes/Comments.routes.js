import { Router } from 'express'
import mysqlConnection from '../database.js'
import * as commentsControllers from '../controllers/Comments.controllers.js'

const router = Router()

router.get('/', commentsControllers.getComements)
router.get('/:id', commentsControllers.getCommentById)
router.post('/', commentsControllers.createComment)
router.put('/:id', commentsControllers.updateComment)
router.delete('/:id', commentsControllers.deleteComment)

export default router
