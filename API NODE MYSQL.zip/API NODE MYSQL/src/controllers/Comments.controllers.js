import mysqlConnection from '../database.js'

export const getComements = async (req, res) => {
  mysqlConnection.query('SELECT * FROM comentarios', (err, rows, fields) => {
    if (!err) {
      res.json(rows)
    } else {
      console.log(err)
    }
  })
}

export const getCommentById = async (req, res) => {
  const { id } = req.params
  mysqlConnection.query(
    'SELECT * FROM comentarios WHERE id = ?',
    [id],
    (err, rows, fields) => {
      if (!err) {
        res.json(rows)
      } else {
        console.log(err)
      }
    }
  )
}

export const createComment = async (req, res) => {
  const { correo, comentario } = req.body
  mysqlConnection.query(
    'INSERT INTO comentarios(correo, comentario) VALUES (?,?)',
    [correo, comentario],
    (err, rows, fields) => {
      if (!err) {
        res.json('Commet add successful')
      } else {
        console.log(err)
      }
    }
  )
}

export const updateComment = async (req, res) => {
  const { id } = req.params
  const { correo, comentario } = req.body
  mysqlConnection.query(
    'UPDATE comentarios SET correo = ? , comentario = ? WHERE id = ?',
    [correo, comentario, id],
    (err, rows, fields) => {
      if (!err) {
        res.json('Comment update successful')
      } else {
        console.log(err)
      }
    }
  )
}

export const deleteComment = async (req, res) => {
  const { id } = req.params
  mysqlConnection.query(
    'DELETE FROM comentarios WHERE id = ?',
    [id],
    (err, rows, fields) => {
      if (!err) {
        res.json('Comment delete successful ')
      } else {
        console.log(err)
      }
    }
  )
}
