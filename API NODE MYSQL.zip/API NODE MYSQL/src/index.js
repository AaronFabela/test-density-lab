import express from 'express'
import cors from 'cors'
import commentsRoutes from './routes/Comments.routes.js'

const app = express()

// Settings
app.set('port', 3000)
app.use(cors())

// Middlewares
app.use(express.json())

// Routes
app.use(commentsRoutes)

// Start Server
app.listen(app.get('port'), () => {
  console.log('Server on port', app.get('port'))
})
